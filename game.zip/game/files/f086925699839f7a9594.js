function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;

    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }

    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }

          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }

        return n[i].exports;
      }

      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) {
        o(t[i]);
      }

      return o;
    }

    return r;
  }()({
    1: [function (require, module, exports) {
      "use strict";

      var ActionType;

      (function (ActionType) {
        ActionType[ActionType["Wait"] = 0] = "Wait";
        ActionType[ActionType["Call"] = 1] = "Call";
        ActionType[ActionType["TweenTo"] = 2] = "TweenTo";
        ActionType[ActionType["TweenBy"] = 3] = "TweenBy";
        ActionType[ActionType["TweenByMult"] = 4] = "TweenByMult";
        ActionType[ActionType["Cue"] = 5] = "Cue";
        ActionType[ActionType["Every"] = 6] = "Every";
      })(ActionType || (ActionType = {}));

      module.exports = ActionType;
    }, {}],
    2: [function (require, module, exports) {
      "use strict";
      /**
       * Easing関数群。
       * 参考: http://gizma.com/easing/
       */

      var Easing;

      (function (Easing) {
        /**
         * 入力値をlinearした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function linear(t, b, c, d) {
          return c * t / d + b;
        }

        Easing.linear = linear;
        /**
         * 入力値をeaseInQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuad(t, b, c, d) {
          t /= d;
          return c * t * t + b;
        }

        Easing.easeInQuad = easeInQuad;
        /**
         * 入力値をeaseOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuad(t, b, c, d) {
          t /= d;
          return -c * t * (t - 2) + b;
        }

        Easing.easeOutQuad = easeOutQuad;
        /**
         * 入力値をeaseInOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutQuad(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t + b;
          --t;
          return -c / 2 * (t * (t - 2) - 1) + b;
        }

        Easing.easeInOutQuad = easeInOutQuad;
        /**
         * 入力値をeaseInQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInCubic(t, b, c, d) {
          t /= d;
          return c * t * t * t + b;
        }

        Easing.easeInCubic = easeInCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInCubic` を用いるべきである。
         */

        Easing.easeInQubic = easeInCubic;
        /**
         * 入力値をeaseOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutCubic(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t + 1) + b;
        }

        Easing.easeOutCubic = easeOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeOutCubic` を用いるべきである。
         */

        Easing.easeOutQubic = easeOutCubic;
        /**
         * 入力値をeaseInOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutCubic(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t + 2) + b;
        }

        Easing.easeInOutCubic = easeInOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInOutCubic` を用いるべきである。
         */

        Easing.easeInOutQubic = easeInOutCubic;
        /**
         * 入力値をeaseInQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuart(t, b, c, d) {
          t /= d;
          return c * t * t * t * t + b;
        }

        Easing.easeInQuart = easeInQuart;
        /**
         * 入力値をeaseOutQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuart(t, b, c, d) {
          t /= d;
          --t;
          return -c * (t * t * t * t - 1) + b;
        }

        Easing.easeOutQuart = easeOutQuart;
        /**
         * 入力値をeaseInQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuint(t, b, c, d) {
          t /= d;
          return c * t * t * t * t * t + b;
        }

        Easing.easeInQuint = easeInQuint;
        /**
         * 入力値をeaseOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuint(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t * t * t + 1) + b;
        }

        Easing.easeOutQuint = easeOutQuint;
        /**
         * 入力値をeaseInOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutQuint(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t * t * t + 2) + b;
        }

        Easing.easeInOutQuint = easeInOutQuint;
        /**
         * 入力値をeaseInSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInSine(t, b, c, d) {
          return -c * Math.cos(t / d * (Math.PI / 2)) + c + b;
        }

        Easing.easeInSine = easeInSine;
        /**
         * 入力値をeaseOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutSine(t, b, c, d) {
          return c * Math.sin(t / d * (Math.PI / 2)) + b;
        }

        Easing.easeOutSine = easeOutSine;
        /**
         * 入力値をeaseInOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutSine(t, b, c, d) {
          return -c / 2 * (Math.cos(Math.PI * t / d) - 1) + b;
        }

        Easing.easeInOutSine = easeInOutSine;
        /**
         * 入力値をeaseInExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInExpo(t, b, c, d) {
          return c * Math.pow(2, 10 * (t / d - 1)) + b;
        }

        Easing.easeInExpo = easeInExpo;
        /**
         * 入力値をeaseInOutExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutExpo(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * Math.pow(2, 10 * (t - 1)) + b;
          --t;
          return c / 2 * (-Math.pow(2, -10 * t) + 2) + b;
        }

        Easing.easeInOutExpo = easeInOutExpo;
        /**
         * 入力値をeaseInCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInCirc(t, b, c, d) {
          t /= d;
          return -c * (Math.sqrt(1 - t * t) - 1) + b;
        }

        Easing.easeInCirc = easeInCirc;
        /**
         * 入力値をeaseOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutCirc(t, b, c, d) {
          t /= d;
          --t;
          return c * Math.sqrt(1 - t * t) + b;
        }

        Easing.easeOutCirc = easeOutCirc;
        /**
         * 入力値をeaseInOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutCirc(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return -c / 2 * (Math.sqrt(1 - t * t) - 1) + b;
          t -= 2;
          return c / 2 * (Math.sqrt(1 - t * t) + 1) + b;
        }

        Easing.easeInOutCirc = easeInOutCirc;
      })(Easing || (Easing = {}));

      module.exports = Easing;
    }, {}],
    3: [function (require, module, exports) {
      "use strict";

      var Tween = require("./Tween");
      /**
       * タイムライン機能を提供するクラス。
       */


      var Timeline =
      /** @class */
      function () {
        /**
         * Timelineを生成する。
         * @param scene タイムラインを実行する `Scene`
         */
        function Timeline(scene) {
          this._scene = scene;
          this._tweens = [];
          this._fps = this._scene.game.fps;
          this.paused = false;
          scene.update.add(this._handler, this);
        }
        /**
         * Timelineに紐付いたTweenを生成する。
         * @param target タイムライン処理の対象にするオブジェクト
         * @param option Tweenの生成オプション。省略された場合、 {modified: target.modified, destroyed: target.destroyed} が与えられた時と同様の処理を行う。
         */


        Timeline.prototype.create = function (target, option) {
          var t = new Tween(target, option);

          this._tweens.push(t);

          return t;
        };
        /**
         * Timelineに紐付いたTweenを削除する。
         * @param tween 削除するTween。
         */


        Timeline.prototype.remove = function (tween) {
          var index = this._tweens.indexOf(tween);

          if (index < 0) {
            return;
          }

          this._tweens.splice(index, 1);
        };
        /**
         * Timelineに紐付いた全Tweenの紐付けを解除する。
         */


        Timeline.prototype.clear = function () {
          this._tweens.length = 0;
        };
        /**
         * このTimelineを破棄する。
         */


        Timeline.prototype.destroy = function () {
          this._tweens.length = 0;

          if (!this._scene.destroyed()) {
            this._scene.update.remove(this._handler, this);
          }

          this._scene = undefined;
        };
        /**
         * このTimelineが破棄済みであるかを返す。
         */


        Timeline.prototype.destroyed = function () {
          return this._scene === undefined;
        };

        Timeline.prototype._handler = function () {
          if (this._tweens.length === 0 || this.paused) {
            return;
          }

          var tmp = [];

          for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];

            if (!tween.isFinished()) {
              tween._fire(1000 / this._fps);

              tmp.push(tween);
            }
          }

          this._tweens = tmp;
        };

        return Timeline;
      }();

      module.exports = Timeline;
    }, {
      "./Tween": 4
    }],
    4: [function (require, module, exports) {
      "use strict";

      var Easing = require("./Easing");

      var ActionType = require("./ActionType");
      /**
       * オブジェクトの状態を変化させるアクションを定義するクラス。
       * 本クラスのインスタンス生成には`Timeline#create()`を利用する。
       */


      var Tween =
      /** @class */
      function () {
        /**
         * Tweenを生成する。
         * @param target 対象となるオブジェクト
         * @param option オプション
         */
        function Tween(target, option) {
          this._target = target;
          this._stepIndex = 0;
          this._loop = !!option && !!option.loop;
          this._modifiedHandler = undefined;

          if (option && option.modified) {
            this._modifiedHandler = option.modified;
          } else if (target && target.modified) {
            this._modifiedHandler = target.modified;
          }

          this._destroyedHandler = undefined;

          if (option && option.destroyed) {
            this._destroyedHandler = option.destroyed;
          } else if (target && target.destroyed) {
            this._destroyedHandler = target.destroyed;
          }

          this._steps = [];
          this._lastStep = undefined;
          this._pararel = false;
          this.paused = false;
        }
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.to = function (props, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: ActionType.TweenTo,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * 変化内容はアクション開始時を基準とした相対値で指定する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         * @param multiply `true`を指定すると`props`の値をアクション開始時の値に掛け合わせた値が終了値となる（指定しない場合は`false`）
         */


        Tween.prototype.by = function (props, duration, easing, multiply) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          if (multiply === void 0) {
            multiply = false;
          }

          var type = multiply ? ActionType.TweenByMult : ActionType.TweenBy;
          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: type,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 次に追加されるアクションを、このメソッド呼び出しの直前に追加されたアクションと並列に実行させる。
         * `Tween#con()`で並列実行を指定されたアクションが全て終了後、次の並列実行を指定されていないアクションを実行する。
         */


        Tween.prototype.con = function () {
          this._pararel = true;
          return this;
        };
        /**
         * オブジェクトの変化を停止するアクションを追加する。
         * @param duration 停止する時間（ミリ秒）
         */


        Tween.prototype.wait = function (duration) {
          var action = {
            duration: duration,
            type: ActionType.Wait,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 関数を即座に実行するアクションを追加する。
         * @param func 実行する関数
         */


        Tween.prototype.call = function (func) {
          var action = {
            func: func,
            type: ActionType.Call,
            duration: 0,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 一時停止するアクションを追加する。
         * 内部的には`Tween#call()`で`Tween#paused`に`true`をセットしている。
         */


        Tween.prototype.pause = function () {
          var _this = this;

          return this.call(function () {
            _this.paused = true;
          });
        };
        /**
         * 待機時間をキーとして実行したい関数を複数指定する。
         * @param actions 待機時間をキーとして実行したい関数を値としたオブジェクト
         */


        Tween.prototype.cue = function (funcs) {
          var keys = Object.keys(funcs);
          keys.sort(function (a, b) {
            return Number(a) > Number(b) ? 1 : -1;
          });
          var q = [];

          for (var i = 0; i < keys.length; ++i) {
            q.push({
              time: Number(keys[i]),
              func: funcs[keys[i]]
            });
          }

          var action = {
            type: ActionType.Cue,
            duration: Number(keys[keys.length - 1]),
            cue: q,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 指定した時間を経過するまで毎フレーム指定した関数を呼び出すアクションを追加する。
         * @param func 毎フレーム呼び出される関数。第一引数は経過時間、第二引数はEasingした結果の変化量（0-1）となる。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.every = function (func, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          var action = {
            func: func,
            type: ActionType.Every,
            easing: easing,
            duration: duration,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * ターゲットをフェードインさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.fadeIn = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            opacity: 1
          }, duration, easing);
        };
        /**
         * ターゲットをフェードアウトさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.fadeOut = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            opacity: 0
          }, duration, easing);
        };
        /**
         * ターゲットを指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveTo = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した相対座標に移動するアクションを追加する。相対座標の基準値はアクション開始時の座標となる。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveBy = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットのX座標を指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveX = function (x, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            x: x
          }, duration, easing);
        };
        /**
         * ターゲットのY座標を指定した座標に移動するアクションを追加する。
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveY = function (y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.rotateTo = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットをアクション開始時の角度を基準とした相対角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.rotateBy = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットを指定した倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.scaleTo = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing);
        };
        /**
         * ターゲットのアクション開始時の倍率に指定した倍率を掛け合わせた倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.scaleBy = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing, true);
        };
        /**
         * アニメーションが終了しているかどうかを返す。
         * `_target`が破棄された場合又は、全アクションの実行が終了した場合に`true`を返す。
         */


        Tween.prototype.isFinished = function () {
          var ret = false;

          if (this._destroyedHandler) {
            ret = this._destroyedHandler.call(this._target);
          }

          if (!ret) {
            ret = this._stepIndex !== 0 && this._stepIndex >= this._steps.length && !this._loop;
          }

          return ret;
        };
        /**
         * アニメーションを実行する。
         * @param delta 前フレームからの経過時間
         */


        Tween.prototype._fire = function (delta) {
          if (this._steps.length === 0 || this.isFinished() || this.paused) {
            return;
          }

          if (this._stepIndex >= this._steps.length) {
            if (this._loop) {
              this._stepIndex = 0;
            } else {
              return;
            }
          }

          var actions = this._steps[this._stepIndex];
          var remained = false;

          for (var i = 0; i < actions.length; ++i) {
            var action = actions[i];

            if (!action.initialized) {
              this._initAction(action);
            }

            if (action.finished) {
              continue;
            }

            action.elapsed += delta;

            switch (action.type) {
              case ActionType.Call:
                action.func.call(this._target);
                break;

              case ActionType.Every:
                var progress = action.easing(action.elapsed, 0, 1, action.duration);

                if (progress > 1) {
                  progress = 1;
                }

                action.func.call(this._target, action.elapsed, progress);
                break;

              case ActionType.TweenTo:
              case ActionType.TweenBy:
              case ActionType.TweenByMult:
                var keys = Object.keys(action.goal);

                for (var j = 0; j < keys.length; ++j) {
                  var key = keys[j];

                  if (action.elapsed >= action.duration) {
                    this._target[key] = action.goal[key];
                  } else {
                    this._target[key] = action.easing(action.elapsed, action.start[key], action.goal[key] - action.start[key], action.duration);
                  }
                }

                break;

              case ActionType.Cue:
                var cueAction = action.cue[action.cueIndex];

                if (cueAction !== undefined && action.elapsed >= cueAction.time) {
                  cueAction.func.call(this._target);
                  ++action.cueIndex;
                }

                break;
            }

            if (this._modifiedHandler) {
              this._modifiedHandler.call(this._target);
            }

            if (action.elapsed >= action.duration) {
              action.finished = true;
            } else {
              remained = true;
            }
          }

          if (!remained) {
            for (var k = 0; k < actions.length; ++k) {
              actions[k].initialized = false;
            }

            ++this._stepIndex;
          }
        };
        /**
         * Tweenの実行状態をシリアライズして返す。
         */


        Tween.prototype.serializeState = function () {
          var tData = {
            _stepIndex: this._stepIndex,
            _steps: []
          };

          for (var i = 0; i < this._steps.length; ++i) {
            tData._steps[i] = [];

            for (var j = 0; j < this._steps[i].length; ++j) {
              tData._steps[i][j] = {
                input: this._steps[i][j].input,
                start: this._steps[i][j].start,
                goal: this._steps[i][j].goal,
                duration: this._steps[i][j].duration,
                elapsed: this._steps[i][j].elapsed,
                type: this._steps[i][j].type,
                cueIndex: this._steps[i][j].cueIndex,
                initialized: this._steps[i][j].initialized,
                finished: this._steps[i][j].finished
              };
            }
          }

          return tData;
        };
        /**
         * Tweenの実行状態を復元する。
         * @param serializedstate 復元に使う情報。
         */


        Tween.prototype.deserializeState = function (serializedState) {
          this._stepIndex = serializedState._stepIndex;

          for (var i = 0; i < serializedState._steps.length; ++i) {
            for (var j = 0; j < serializedState._steps[i].length; ++j) {
              if (!serializedState._steps[i][j] || !this._steps[i][j]) continue;
              this._steps[i][j].input = serializedState._steps[i][j].input;
              this._steps[i][j].start = serializedState._steps[i][j].start;
              this._steps[i][j].goal = serializedState._steps[i][j].goal;
              this._steps[i][j].duration = serializedState._steps[i][j].duration;
              this._steps[i][j].elapsed = serializedState._steps[i][j].elapsed;
              this._steps[i][j].type = serializedState._steps[i][j].type;
              this._steps[i][j].cueIndex = serializedState._steps[i][j].cueIndex;
              this._steps[i][j].initialized = serializedState._steps[i][j].initialized;
              this._steps[i][j].finished = serializedState._steps[i][j].finished;
            }
          }
        };
        /**
         * `this._pararel`が`false`の場合は新規にステップを作成し、アクションを追加する。
         * `this._pararel`が`true`の場合は最後に作成したステップにアクションを追加する。
         */


        Tween.prototype._push = function (action) {
          if (this._pararel) {
            this._lastStep.push(action);
          } else {
            var index = this._steps.push([action]) - 1;
            this._lastStep = this._steps[index];
          }

          this._pararel = false;
        };

        Tween.prototype._initAction = function (action) {
          action.elapsed = 0;
          action.start = {};
          action.goal = {};
          action.cueIndex = 0;
          action.finished = false;
          action.initialized = true;

          if (action.type !== ActionType.TweenTo && action.type !== ActionType.TweenBy && action.type !== ActionType.TweenByMult) {
            return;
          }

          var keys = Object.keys(action.input);

          for (var i = 0; i < keys.length; ++i) {
            var key = keys[i];

            if (this._target[key] !== undefined) {
              action.start[key] = this._target[key];

              if (action.type === ActionType.TweenTo) {
                action.goal[key] = action.input[key];
              } else if (action.type === ActionType.TweenBy) {
                action.goal[key] = action.start[key] + action.input[key];
              } else if (action.type === ActionType.TweenByMult) {
                action.goal[key] = action.start[key] * action.input[key];
              }
            }
          }
        };

        return Tween;
      }();

      module.exports = Tween;
    }, {
      "./ActionType": 1,
      "./Easing": 2
    }],
    5: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Timeline = require("./Timeline");
      exports.Tween = require("./Tween");
      exports.Easing = require("./Easing");
    }, {
      "./Easing": 2,
      "./Timeline": 3,
      "./Tween": 4
    }],
    6: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics = function extendStatics(d, b) {
          _extendStatics = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics(d, b);
        };

        return function (d, b) {
          _extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Button = void 0;

      var Button =
      /** @class */
      function (_super) {
        __extends(Button, _super);

        function Button(scene, s, x, y, w, h) {
          if (x === void 0) {
            x = 0;
          }

          if (y === void 0) {
            y = 0;
          }

          if (w === void 0) {
            w = 100;
          }

          if (h === void 0) {
            h = 50;
          }

          var _this = _super.call(this, {
            scene: scene,
            cssColor: "black",
            width: w,
            height: h,
            x: x,
            y: y,
            touchable: true
          }) || this;

          _this.num = 0;

          _this.chkEnable = function (ev) {
            return true;
          }; // this.pushEvent = () => {};


          if (Button.font == null) {
            Button.font = new g.DynamicFont({
              game: g.game,
              fontFamily: g.FontFamily.Monospace,
              size: 32
            });
          }

          var base = new g.FilledRect({
            scene: scene,
            x: 2,
            y: 2,
            width: w - 4,
            height: h - 4,
            cssColor: "white"
          });

          _this.append(base);

          _this.label = new g.Label({
            scene: scene,
            font: Button.font,
            text: s[0],
            fontSize: 24,
            textColor: "black",
            widthAutoAdjust: false,
            textAlign: g.TextAlign.Center,
            width: w - 4
          });
          _this.label.y = (h - 4 - _this.label.height) / 2;

          _this.label.modified();

          base.append(_this.label);

          _this.pointDown.add(function (ev) {
            if (!_this.chkEnable(ev)) return;
            base.cssColor = "gray";
            base.modified();

            if (s.length !== 1) {
              _this.num = (_this.num + 1) % s.length;
              _this.label.text = s[_this.num];

              _this.label.invalidate();
            }
          });

          _this.pointUp.add(function (ev) {
            base.cssColor = "white";
            base.modified();

            _this.pushEvent(ev);
          });

          return _this;
        }

        return Button;
      }(g.FilledRect);

      exports.Button = Button;
    }, {}],
    7: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics2 = function extendStatics(d, b) {
          _extendStatics2 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics2(d, b);
        };

        return function (d, b) {
          _extendStatics2(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Config = void 0;

      var Button_1 = require("./Button");

      var Config =
      /** @class */
      function (_super) {
        __extends(Config, _super);

        function Config(scene, x, y) {
          if (x === void 0) {
            x = 0;
          }

          if (y === void 0) {
            y = 0;
          }

          var _this = _super.call(this, {
            scene: scene,
            cssColor: "black",
            width: 250,
            height: 250,
            x: x,
            y: y,
            touchable: true
          }) || this;

          _this.num = 0;
          _this.volumes = [0.5, 0.8];

          _this.chkEnable = function (ev) {
            return true;
          }; // const events = [this.bgmEvent, this.seEvent];


          var font = new g.DynamicFont({
            game: g.game,
            fontFamily: g.FontFamily.Monospace,
            size: 32
          });
          var base = new g.FilledRect({
            scene: scene,
            x: 2,
            y: 2,
            width: _this.width - 4,
            height: _this.height - 4,
            cssColor: "white"
          });

          _this.append(base);

          base.append(new g.Label({
            scene: scene,
            font: font,
            text: "設定",
            fontSize: 24,
            textColor: "black",
            widthAutoAdjust: false,
            textAlign: g.TextAlign.Center,
            width: 250
          }));
          var line = new g.FilledRect({
            scene: scene,
            x: 5,
            y: 30,
            width: 235,
            height: 2,
            cssColor: "#000000"
          });
          base.append(line);
          var strVol = ["ＢＧＭ", "効果音"];

          var _loop_1 = function _loop_1(i) {
            base.append(new g.Label({
              scene: scene,
              font: font,
              text: strVol[i],
              fontSize: 24,
              textColor: "black",
              x: 10,
              y: 50 + 50 * i
            }));
            var sprVol = new g.FrameSprite({
              scene: scene,
              src: scene.assets.volume,
              width: 32,
              height: 32,
              x: 90,
              y: 50 + 50 * i,
              frames: [0, 1]
            });
            base.append(sprVol);
            var baseVol = new g.E({
              scene: scene,
              x: 130,
              y: 50 + 50 * i,
              width: 110,
              height: 32,
              touchable: true
            });
            base.append(baseVol);
            var lineVol = new g.FilledRect({
              scene: scene,
              x: 0,
              y: 13,
              width: 110,
              height: 6,
              cssColor: "gray"
            });
            baseVol.append(lineVol);
            var cursorVol = new g.FilledRect({
              scene: scene,
              x: 110 * this_1.volumes[i] - 7,
              y: 0,
              width: 15,
              height: 32,
              cssColor: "#000000"
            });
            baseVol.append(cursorVol);
            var flgMute = false;
            baseVol.pointMove.add(function (e) {
              var posX = e.point.x + e.startDelta.x;
              if (posX < 7) posX = 7;
              if (posX > 103) posX = 103;
              cursorVol.x = posX - 7;
              cursorVol.modified();
              flgMute = posX - 7 === 0;
            });
            baseVol.pointUp.add(function (e) {
              if (flgMute) {
                sprVol.frameNumber = 1;
              } else {
                sprVol.frameNumber = 0;
              }

              sprVol.modified();
              _this.volumes[i] = cursorVol.x / 110;

              if (i === 0 && _this.bgmEvent !== undefined) {
                _this.bgmEvent(_this.volumes[i]);
              }
            });
          };

          var this_1 = this;

          for (var i = 0; i < 2; i++) {
            _loop_1(i);
          }

          var colors = ["gray", "black", "white", "green", "navy"];
          var colorNum = 0; // 背景色

          base.append(new g.Label({
            scene: scene,
            font: font,
            text: "背景色",
            fontSize: 24,
            textColor: "black",
            x: 10,
            y: 150
          }));
          base.append(new g.FilledRect({
            scene: scene,
            x: 130,
            y: 150,
            width: 110,
            height: 40,
            cssColor: "#000000"
          }));
          var sprColor = new g.FilledRect({
            scene: scene,
            x: 132,
            y: 152,
            width: 106,
            height: 36,
            cssColor: "gray",
            touchable: true
          });
          base.append(sprColor);
          sprColor.pointDown.add(function (e) {
            colorNum = (colorNum + 1) % colors.length;
            sprColor.cssColor = colors[colorNum];
            sprColor.modified();

            if (_this.colorEvent !== undefined) {
              _this.colorEvent(colors[colorNum]);
            }
          }); // ランキング表示

          var btnRank = new Button_1.Button(scene, ["ランキング"], 2, 198, 130, 45);
          base.append(btnRank);

          btnRank.pushEvent = function () {
            if (typeof window !== "undefined" && window.RPGAtsumaru) {
              window.RPGAtsumaru.scoreboards.display(1);
            }
          }; // 閉じる


          var btnClose = new Button_1.Button(scene, ["閉じる"], 138, 198, 105, 45);
          base.append(btnClose);

          btnClose.pushEvent = function () {
            _this.hide();
          };

          return _this;
        }

        return Config;
      }(g.FilledRect);

      exports.Config = Config;
    }, {
      "./Button": 6
    }],
    8: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics3 = function extendStatics(d, b) {
          _extendStatics3 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics3(d, b);
        };

        return function (d, b) {
          _extendStatics3(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.MainGame = void 0; // メインのゲーム画面

      var MainGame =
      /** @class */
      function (_super) {
        __extends(MainGame, _super);

        function MainGame(scene) {
          var _this = this; // eslint-disable-next-line @typescript-eslint/no-var-requires


          var tl = require("@akashic-extension/akashic-timeline");

          var timeline = new tl.Timeline(scene);
          _this = _super.call(this, {
            scene: scene,
            x: 0,
            y: 0,
            width: 640,
            height: 360
          }) || this;
          var bg = new g.FilledRect({
            scene: scene,
            width: g.game.width,
            height: g.game.height,
            cssColor: "white",
            opacity: 0.5
          });

          _this.append(bg); //マップ


          var mapBase = new g.FilledRect({
            scene: scene,
            x: 60,
            y: 5,
            width: 320,
            height: 360,
            touchable: true,
            cssColor: "white"
          });

          _this.append(mapBase);

          var mapRow = 4;
          var mapColumn = 8;
          var maps = [];

          for (var x = 0; x < mapRow; x++) {
            maps[x] = [];

            for (var y = 0; y < mapColumn + 1; y++) {
              var w = mapBase.width / mapRow;
              var h = 320 / mapColumn;
              maps[x][y] = new Map(scene, w * x, h * y, w - 1, h - 1);
              mapBase.append(maps[x][y]);
              maps[x][y].num = y !== mapColumn ? -1 : 4;
            }
          } //枠線(左右)


          for (var x = 0; x < 2; x++) {
            var line = new g.Sprite({
              scene: scene,
              src: scene.assets.line,
              x: x * 380
            });

            _this.append(line);
          } //消えた数表示用


          var labels = [];

          for (var i = 0; i < 2; i++) {
            var label = new g.Label({
              scene: scene,
              font: scene.numFontP,
              fontSize: 72,
              text: "0"
            });
            labels.push(label);
          } // つぎ


          _this.append(new g.Sprite({
            scene: scene,
            src: scene.assets.score,
            x: 450,
            y: 100,
            height: 32,
            srcY: 64
          })); //詰みライン


          mapBase.append(new g.FilledRect({
            scene: scene,
            x: 0,
            y: 320 / mapColumn,
            width: 320,
            height: 2,
            cssColor: "red"
          })); //コーン

          for (var i = 0; i < mapRow; i++) {
            var map = maps[i][mapColumn];
            var block = new Block({
              scene: scene,
              width: mapBase.width / mapRow - 2,
              height: mapBase.height / mapColumn - 2,
              x: map.x,
              y: map.y
            });
            mapBase.append(block);
            map.block = block;
            block.setColor(5);
          } //ブロック


          var blocks = [];

          for (var i = 0; i < mapRow * mapColumn; i++) {
            var block = new Block({
              scene: scene,
              width: mapBase.width / mapRow,
              height: mapBase.height / mapColumn
            });
            blocks.push(block);
          } //列入れ替え


          var swap = function swap(x, mx) {
            //移動中のブロックが邪魔している時は入れ替えない
            for (var i = mapColumn - 1; i >= 0; i--) {
              var mapA = maps[x][i];
              var mapB = maps[x + mx][i];

              if (mapA.isMoveBlock && mapB.block || mapA.block && mapB.isMoveBlock) {
                return;
              }
            }

            var _loop_1 = function _loop_1(i) {
              var mapA = maps[x][i];
              var mapB = maps[x + mx][i];
              if (!mapA.block && !mapB.block) return "break"; //入れ替え

              var bkBlock = mapA.block;
              mapA.block = mapB.block;
              mapB.block = bkBlock; //位置入れ替えるアニメーション

              [mapA, mapB].forEach(function (map) {
                if (map.block) {
                  timeline.create(map.block).wait((mapColumn - i) * 30).moveTo(map.x, map.y, 200);
                }
              });
            };

            for (var i = mapColumn; i >= 0; i--) {
              var state_1 = _loop_1(i);

              if (state_1 === "break") break;
            }
          };

          var px = 0;
          mapBase.pointDown.add(function (ev) {
            px = Math.floor(ev.point.x / (mapBase.width / mapRow));
          });
          mapBase.pointMove.add(function (ev) {
            if (px === -1 || isStop || !scene.isStart) return;
            var x = Math.floor((ev.point.x + ev.startDelta.x) / (mapBase.width / mapRow));

            if (x !== px && x >= 0 && x < mapRow) {
              if (x < px) {
                swap(px, -1);
              } else {
                swap(px, 1);
              }

              px = -1;
            }
          }); //次のブロックを出す

          var moveBlocks = [];
          var nextBlocks = [];

          var nextBlock = function nextBlock() {
            nextBlocks.forEach(function (block) {
              var map = maps[block.px][block.py];
              block.moveTo(map.x, map.y);
              mapBase.append(block);
              moveBlocks.push(block);
            });
            var bkNum = 0;

            for (var i = 0; i < 2; i++) {
              var block = blocks.pop(); //同じ位置に２つ出ないようにするクソコード

              if (i === 0) {
                block.px = scene.random.get(0, 3);
                bkNum = block.px;
              } else {
                while (true) {
                  block.px = scene.random.get(0, 3);
                  if (bkNum !== block.px) break;
                }
              }

              block.py = 0;
              block.cnt = 0;
              block.moveTo(450 + i * 70, 150);
              block.setColor(scene.random.get(0, 4));

              _this.append(block);

              nextBlocks[i] = block;
            }
          }; //そろったブロックを消す


          var clearBlock = function clearBlock(x, y) {
            var score = 0;
            if (y > mapColumn - 2) return score;
            var num = maps[x][y].block.colorNum;
            if (num === maps[x][y + 1].block.colorNum) return score;

            var _loop_2 = function _loop_2(i) {
              if (i !== y + 1 && maps[x][i].block.colorNum === num) {
                for (var j = y; j <= i; j++) {
                  var block = maps[x][j].block;
                  block.put();
                }

                var label_1 = labels.pop();
                label_1.x = maps[x][y].x + 10;
                label_1.y = maps[x][y + 1].y;
                label_1.text = "" + (i - y + 1);
                label_1.invalidate();
                mapBase.append(label_1);
                timeline.create(label_1).moveBy(0, -30, 500).call(function () {
                  label_1.remove();
                  labels.push(label_1);
                });
                isStop = true;
                timeline.create().wait(500).call(function () {
                  for (var j = y; j <= i; j++) {
                    var block = maps[x][j].block;
                    blocks.unshift(block);
                    block.remove();
                    maps[x][j].block = null;
                  }

                  isStop = false;
                });
                score = Math.pow(i - y, 3) * 60;
                return "break";
              }
            };

            for (var i = y + 2; i < mapColumn; i++) {
              var state_2 = _loop_2(i);

              if (state_2 === "break") break;
            }

            return score;
          }; //詰みの判定


          var checkMate = function checkMate() {
            for (var x = 0; x < mapRow; x++) {
              if (maps[x][0].block) return true;
            }

            return false;
          }; // メインループ


          var isStop = false;
          var score = 0; //加算するスコア

          mapBase.update.add(function () {
            if (!scene.isStart) return; // ブロックを落とす

            moveBlocks = moveBlocks.filter(function (block) {
              if (!block) return; // const time = (mapColumn - block.py) * 3;

              var time = 5;

              if (block.cnt > 30 && block.cnt % time === time - 1) {
                maps[block.px][block.py].isMoveBlock = false;
                var map = maps[block.px][block.py + 1];

                if (!map.block) {
                  timeline.create(block).moveTo(map.x, map.y, time / 30 * 1000);
                  block.py++;
                  map.isMoveBlock = true;
                } else {
                  // ブロック配置
                  maps[block.px][block.py].block = block;
                  block.put(); // 消える処理

                  score += clearBlock(block.px, block.py);
                  scene.playSound("se_move");
                  return false;
                }
              }

              block.cnt++;
              return true;
            });

            if (moveBlocks.length === 0 && !isStop) {
              if (score > 0) {
                scene.addScore(score);
                scene.playSound("se_hit");
              }

              score = 0; //詰みの判定

              if (!checkMate()) {
                //次のブロックを出す
                nextBlock();
              } else {
                _this.reset();
              }
            }
          }); // 終了

          _this.finish = function () {
            return;
          }; // リセット


          _this.reset = function () {
            //マップのクリア
            for (var x = 0; x < mapRow; x++) {
              for (var y = 0; y < mapColumn; y++) {
                var map = maps[x][y];

                if (map.block) {
                  blocks.unshift(map.block);
                  map.block.remove();
                  map.block = null;
                }

                map.isMoveBlock = false;
              }
            } //移動中のブロックのクリア


            moveBlocks.forEach(function (block) {
              blocks.unshift(block);
              block.remove();
            });
            moveBlocks.length = 0;
            nextBlocks.forEach(function (block) {
              blocks.unshift(block);
              block.remove();
            });
            nextBlocks.length = 0;
            score = 0;
            nextBlock();
            nextBlock();
            return;
          };

          return _this;
        }

        return MainGame;
      }(g.E);

      exports.MainGame = MainGame; //マップクラス

      var Map =
      /** @class */
      function (_super) {
        __extends(Map, _super);

        function Map(scene, x, y, w, h) {
          var _this = _super.call(this, {
            scene: scene,
            x: x,
            y: y,
            width: w,
            height: h,
            cssColor: "#CCFFFF"
          }) || this;

          _this.num = 0;
          _this.block = null;
          _this.isMoveBlock = false;
          return _this;
        }

        return Map;
      }(g.FilledRect); //ブロッククラス


      var Block =
      /** @class */
      function (_super) {
        __extends(Block, _super);

        function Block(pram) {
          var _this = _super.call(this, pram) || this;

          _this.cnt = 0;
          _this.px = 0;
          _this.py = 0;
          _this.colorNum = 0;
          var size = 60;
          var spr = new g.FrameSprite({
            scene: pram.scene,
            src: pram.scene.assets.ice,
            width: size,
            height: size,
            x: (_this.width - size) / 2,
            y: (_this.height - size) / 2,
            frames: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17],
            frameNumber: 0
          });

          _this.append(spr);

          _this.setColor = function (num) {
            _this.colorNum = num;
            spr.frameNumber = num;
            spr.modified();
          }; //乗せる


          _this.put = function () {
            spr.frameNumber += 6;
            spr.modified();
          };

          return _this;
        }

        return Block;
      }(g.E);
    }, {
      "@akashic-extension/akashic-timeline": 5
    }],
    9: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics4 = function extendStatics(d, b) {
          _extendStatics4 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (b.hasOwnProperty(p)) d[p] = b[p];
            }
          };

          return _extendStatics4(d, b);
        };

        return function (d, b) {
          _extendStatics4(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.MainScene = void 0;

      var Button_1 = require("./Button");

      var Config_1 = require("./Config");

      var MainGame_1 = require("./MainGame");

      var MainScene =
      /** @class */
      function (_super) {
        __extends(MainScene, _super);

        function MainScene(param) {
          var _this = this;

          param.assetIds = ["img_numbers_n", "img_numbers_n_red", "title", "start", "finish", "score", "time", "waku", "effect", "ice", "line", "config", "volume", "test", "glyph72", "number_k", "number_b", "number_y", "number_p", "se_start", "se_timeup", "bgm", "se_move", "se_miss", "se_hit", "se_item"];
          _this = _super.call(this, param) || this; // eslint-disable-next-line @typescript-eslint/no-var-requires

          var tl = require("@akashic-extension/akashic-timeline");

          var timeline = new tl.Timeline(_this);
          var timeline2 = new tl.Timeline(_this);
          var isDebug = false;

          _this.loaded.add(function () {
            g.game.vars.gameState = {
              score: 0
            }; // 何も送られてこない時は、標準の乱数生成器を使う

            _this.random = g.game.random; // ミニゲームチャット用モードの取得と乱数シード設定

            var mode = "";

            if (typeof window !== "undefined") {
              var url = new URL(location.href);
              var seed = url.searchParams.get("date"); // eslint-disable-next-line radix

              if (seed) _this.random = new g.XorshiftRandomGenerator(parseInt(seed));
              mode = url.searchParams.get("mode");
            }

            _this.message.add(function (msg) {
              if (msg.data && msg.data.type === "start" && msg.data.parameters) {
                // セッションパラメータのイベント
                var sessionParameters = msg.data.parameters;

                if (sessionParameters.randomSeed != null) {
                  // プレイヤー間で共通の乱数生成器を生成
                  // `g.XorshiftRandomGenerator` は Akashic Engine の提供する乱数生成器実装で、 `g.game.random` と同じ型。
                  _this.random = new g.XorshiftRandomGenerator(sessionParameters.randomSeed);
                }
              }
            }); // 配信者のIDを取得


            _this.lastJoinedPlayerId = "";
            g.game.join.add(function (ev) {
              _this.lastJoinedPlayerId = ev.player.id;
            }); // 背景

            var bg = new g.FilledRect({
              scene: _this,
              width: 640,
              height: 360,
              cssColor: "#303030",
              opacity: 0
            });

            _this.append(bg);

            if (typeof window !== "undefined" && window.RPGAtsumaru || isDebug || mode === "game") {
              bg.opacity = 1.0;
              bg.modified();
            } else {
              bg.opacity = 0.8;
              bg.modified();
            }

            var base = new g.E({
              scene: _this
            });

            _this.append(base);

            base.hide();
            var uiBase = new g.E({
              scene: _this
            });

            _this.append(uiBase);

            uiBase.hide(); // タイトル

            var sprTitle = new g.Sprite({
              scene: _this,
              src: _this.assets.title,
              x: 0
            });

            _this.append(sprTitle);

            timeline.create(sprTitle, {
              modified: sprTitle.modified,
              destroyd: sprTitle.destroyed
            }).wait(isDebug ? 1000 : 5000).moveBy(-800, 0, 200).call(function () {
              bg.show();
              base.show();
              uiBase.show();
              _this.isStart = true;
              reset();
            });
            var glyph = JSON.parse(_this.assets.test.data);
            var numFont = new g.BitmapFont({
              src: _this.assets.img_numbers_n,
              map: glyph.map,
              defaultGlyphWidth: glyph.width,
              defaultGlyphHeight: glyph.height,
              missingGlyph: glyph.missingGlyph
            });
            _this.numFont = numFont;
            var numFontRed = new g.BitmapFont({
              src: _this.assets.img_numbers_n_red,
              map: glyph.map,
              defaultGlyphWidth: glyph.width,
              defaultGlyphHeight: glyph.height,
              missingGlyph: glyph.missingGlyph
            });
            _this.numFontR = numFontRed;
            glyph = JSON.parse(_this.assets.glyph72.data);
            var numFontB = new g.BitmapFont({
              src: _this.assets.number_b,
              map: glyph.map,
              defaultGlyphWidth: 65,
              defaultGlyphHeight: 80
            });
            _this.numFontB = numFontB;
            var numFontK = new g.BitmapFont({
              src: _this.assets.number_k,
              map: glyph.map,
              defaultGlyphWidth: 65,
              defaultGlyphHeight: 80
            });
            _this.numFontK = numFontK;
            _this.numFontY = new g.BitmapFont({
              src: _this.assets.number_y,
              map: glyph.map,
              defaultGlyphWidth: 72,
              defaultGlyphHeight: 80
            });
            _this.numFontP = new g.BitmapFont({
              src: _this.assets.number_p,
              map: glyph.map,
              defaultGlyphWidth: 72,
              defaultGlyphHeight: 80
            }); // スコア

            uiBase.append(new g.Sprite({
              scene: _this,
              src: _this.assets.score,
              x: 450,
              y: 0,
              height: 32
            }));
            var score = 0;
            var labelScore = new g.Label({
              scene: _this,
              x: 430,
              y: 35,
              width: 32 * 6,
              fontSize: 32,
              font: numFont,
              text: "0P",
              textAlign: g.TextAlign.Right,
              widthAutoAdjust: false
            });
            uiBase.append(labelScore);
            var labelScorePlus = new g.Label({
              scene: _this,
              x: 312,
              y: 70,
              width: 32 * 10,
              fontSize: 32,
              font: numFontRed,
              text: "+0",
              textAlign: g.TextAlign.Right,
              widthAutoAdjust: false
            });
            uiBase.append(labelScorePlus); // タイム

            uiBase.append(new g.Sprite({
              scene: _this,
              src: _this.assets.time,
              x: 525,
              y: 320
            }));
            var labelTime = new g.Label({
              scene: _this,
              font: numFont,
              fontSize: 32,
              text: "70",
              x: 565,
              y: 323
            });
            uiBase.append(labelTime); // 開始

            var sprStart = new g.Sprite({
              scene: _this,
              src: _this.assets.start,
              x: 50,
              y: 100
            });
            uiBase.append(sprStart);
            sprStart.hide(); // 終了

            var finishBase = new g.E({
              scene: _this,
              x: 0,
              y: 0
            });

            _this.append(finishBase);

            finishBase.hide();
            var finishBg = new g.FilledRect({
              scene: _this,
              width: 640,
              height: 360,
              cssColor: "#000000",
              opacity: 0.3
            });
            finishBase.append(finishBg);
            var sprFinish = new g.Sprite({
              scene: _this,
              src: _this.assets.finish,
              x: 120,
              y: 100
            });
            finishBase.append(sprFinish); // 最前面

            var fg = new g.FilledRect({
              scene: _this,
              width: 640,
              height: 360,
              cssColor: "#ff0000",
              opacity: 0.0
            });

            _this.append(fg); // リセットボタン


            var btnReset = new Button_1.Button(_this, ["リセット"], 500, 260, 130);

            if (typeof window !== "undefined" && window.RPGAtsumaru || isDebug || mode === "game") {
              finishBase.append(btnReset);

              btnReset.pushEvent = function () {
                reset();
              };
            } // ランキングボタン


            var btnRanking = new Button_1.Button(_this, ["ランキング"], 500, 200, 130);

            if (typeof window !== "undefined" && window.RPGAtsumaru || isDebug) {
              finishBase.append(btnRanking);

              btnRanking.pushEvent = function () {
                window.RPGAtsumaru.scoreboards.display(1);
              };
            } // 設定ボタン


            var btnConfig = new g.Sprite({
              scene: _this,
              x: 600,
              y: 0,
              src: _this.assets.config,
              touchable: true
            });

            if (typeof window !== "undefined" && window.RPGAtsumaru || isDebug || mode === "game") {
              _this.append(btnConfig);
            } // 設定画面


            var config = new Config_1.Config(_this, 380, 40);

            if (typeof window !== "undefined" && window.RPGAtsumaru || isDebug || mode === "game") {
              _this.append(config);
            }

            config.hide();
            btnConfig.pointDown.add(function () {
              if (config.state & 1) {
                config.show();
              } else {
                config.hide();
              }
            });

            config.bgmEvent = function (num) {
              bgm.changeVolume(0.5 * num);
            };

            config.colorEvent = function (str) {
              bg.cssColor = str;
              bg.modified();
            };

            var bgm = _this.assets.bgm.play();

            bgm.changeVolume(isDebug ? 0.0 : 0.2);

            _this.playSound = function (name) {
              _this.assets[name].play().changeVolume(config.volumes[1]);
            }; // ゲームメイン


            var game = new MainGame_1.MainGame(_this);
            base.append(game); // メインループ

            var bkTime = 0;
            var timeLimit = 90;
            var startTime = 0;

            _this.update.add(function () {
              // return;//デバッグ
              if (!_this.isStart) return;
              var t = timeLimit - Math.floor((Date.now() - startTime) / 1000); // 終了処理

              if (t <= -1) {
                fg.cssColor = "#000000";
                fg.opacity = 0.0;
                fg.modified();
                finishBase.show();
                _this.isStart = false;

                _this.playSound("se_timeup");

                timeline.create().wait(2500).call(function () {
                  if (typeof window !== "undefined" && window.RPGAtsumaru) {
                    window.RPGAtsumaru.scoreboards.setRecord(1, g.game.vars.gameState.score).then(function () {
                      btnRanking.show();
                      btnReset.show();
                    });
                  }

                  if (isDebug) {
                    btnRanking.show();
                    btnReset.show();
                  } // ミニゲームチャット用ランキング設定


                  if (mode === "game") {
                    window.parent.postMessage({
                      score: g.game.vars.gameState.score,
                      id: 1
                    }, "*");
                    btnReset.show();
                  }
                });
                game.finish();
                return;
              }

              labelTime.text = "" + t;
              labelTime.invalidate();

              if (bkTime !== t && t <= 5) {
                fg.opacity = 0.1;
                fg.modified();
                timeline.create().wait(500).call(function () {
                  fg.opacity = 0.0;
                  fg.modified();
                });
              }

              bkTime = t;
            }); // スコア加算表示


            var bkTweenScore;

            _this.addScore = function (num) {
              if (score + num < 0) {
                num = -score;
              }

              score += num;
              timeline.create().every(function (e, p) {
                labelScore.text = "" + (score - Math.floor(num * (1 - p))) + "P";
                labelScore.invalidate();
              }, 500);
              labelScorePlus.text = (num >= 0 ? "+" : "") + num;
              labelScorePlus.invalidate();
              if (bkTweenScore) timeline2.remove(bkTweenScore);
              bkTweenScore = timeline2.create().every(function (e, p) {
                labelScorePlus.opacity = p;
                labelScorePlus.modified();
              }, 100).wait(4000).call(function () {
                labelScorePlus.opacity = 0;
                labelScorePlus.modified();
              });
              g.game.vars.gameState.score = score;
              if (typeof window !== "undefined") window.score = score;
            }; // リセット


            var reset = function reset() {
              bkTime = 0;
              startTime = Date.now();
              _this.isStart = true;
              score = 0;
              labelScore.text = "0P";
              labelScore.invalidate();
              labelScorePlus.text = "";
              labelScorePlus.invalidate();
              sprStart.show();
              timeline.create().wait(750).call(function () {
                sprStart.hide();
              });
              btnReset.hide();
              btnRanking.hide();
              fg.opacity = 0;
              fg.modified();
              finishBase.hide();
              startTime = Date.now();
              game.reset();

              _this.playSound("se_start");
            };
          });

          return _this;
        }

        return MainScene;
      }(g.Scene);

      exports.MainScene = MainScene;
    }, {
      "./Button": 6,
      "./Config": 7,
      "./MainGame": 8,
      "@akashic-extension/akashic-timeline": 5
    }],
    10: [function (require, module, exports) {
      var MainScene_1 = require("./MainScene");

      function main(param) {
        // const DEBUG_MODE: boolean = true;
        var scene = new MainScene_1.MainScene({
          game: g.game
        });
        g.game.pushScene(scene);
      }

      module.exports = main;
    }, {
      "./MainScene": 9
    }]
  }, {}, [10])(10);
});